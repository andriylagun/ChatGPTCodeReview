({
    doInit : function( component, event, helper ) {
        let pageRef = component.get("v.pageReference");
        let state = pageRef.state;
        let base64Context = state.inContextOfRef;
        if (base64Context.startsWith("1\.")) {
            base64Context = base64Context.substring(2);
        }
        let addressableContext = JSON.parse(window.atob(base64Context));
        component.set("v.recordId", addressableContext.attributes.recordId);
    }
})