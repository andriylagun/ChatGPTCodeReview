({
    doInit: function (component, event, helper) {
        var pageRef = component.get("v.pageReference");
        var state = pageRef.state;
        var base64Context = state.inContextOfRef;
        if (base64Context.startsWith("1\.")) {
            base64Context = base64Context.substring(2);
        }
        var addressableContext = JSON.parse(window.atob(base64Context));
        component.set("v.recordId", addressableContext.attributes.recordId);

        var recordId = component.get("v.recordId");
        var action = component.get("c.getChildConditionRecord");
        action.setParams({parentId: recordId});

        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var parentRecord = response.getReturnValue();

                var createRecordEvent = $A.get("e.force:createRecord");
                createRecordEvent.setParams({
                    entityApiName: 'FIN_AXSRuleCondition__c',
                    recordTypeId: parentRecord.recordTypeId,
                    defaultFieldValues: {
                        'FIN_SortingRule__c': parentRecord.ruleEngine.Id,
                        'FIN_Object__c': parentRecord.ruleEngine.FIN_Object__c
                    }
                });
                createRecordEvent.fire();
            } else {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.error(errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });

        $A.enqueueAction(action);
    }
})
